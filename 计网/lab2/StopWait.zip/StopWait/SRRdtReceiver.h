#pragma once
#ifndef SR_RDTRECEIVER_H
#define SR_RDTRECEIVER_H
#include"RdtReceiver.h"
#include<deque>
#define WINDOW_SIZE 4
#define WINDOW_SEQ 8

class SRRdtReceiver :public RdtReceiver {
private:
	int base;
	int window_size;
	Packet lastAckPkt; 
	std::deque<Packet *>window;
public:
	SRRdtReceiver();
	~SRRdtReceiver();
public:
	void receive(Packet &packet);
};
#endif // !SR_RDTRECEIVER_H
