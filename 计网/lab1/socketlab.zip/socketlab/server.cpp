#include"Config.h"
#include<WinSock2.h>
#include <iostream>
#include<Windows.h>
#include <string>
#include <WS2tcpip.h>
#include<thread>
//#include<string.h>
#include<stdlib.h>
//#define BUFFERLENGTH 65536

#pragma comment(lib, "Ws2_32.lib")
#pragma warning(disable:4996)
using namespace std;

void esc_key(void) {
	while (1) {
		int check = GetKeyState(VK_ESCAPE);
		if (check < 0)
		{
			WSACleanup();
			exit(-1);
		}
	}
}//���Esc��

DWORD WINAPI CreateClientThread(LPVOID lpParameter)
{
	SOCKET socket= (SOCKET)lpParameter;
	int rtn = 0;
	int ret_val = 0;
	int snd_result = 0;
	
	FILE *fp; //�ļ�ָ��
	char *method;//GET or POST
	char url[256], url_temp[64], type[16];//url����·�� url_temp���·�� type �ļ�����
	char content[65536];// 
	int lenth;//�ļ�����
	char lenth_str[64];//ת��Ϊ�ַ���
	char* req;
	char* res;  //req���������ģ�res������Ӧ����
	req = new char[Config::BUFFERLENGTH]; //��ʼ�����ܻ�����
	res = new char[Config::BUFFERLENGTH]; 
	memset(req, '\0', Config::BUFFERLENGTH);
	memset(res, '\0', Config::BUFFERLENGTH);//�������ÿ�
	//do
	//{
		 rtn = recv(socket, req, Config::BUFFERLENGTH, 0);
		if (rtn > 0)
		{
			//req[rtn] = '\0';
			cout << req << endl;//��ӡ������
			//	memset(rcvData, '\0', Config::BUFFERLENGTH); //������ܻ�����
				method = strstr(req, "GET");//GET�Ƿ����req��
				
				if (method)
				{
                   strncpy(url_temp, strchr(req, '/') + 1, (strstr(req, "HTTP") - strchr(req, '/') - 2));
				   url_temp[strstr(req, "HTTP") - strchr(req, '/') - 2] = '\0';
				   if (strchr(url_temp, '.') == NULL) { //�޺�׺ +index.html
					  strcat(url_temp, "index.html");
				}
			    }
			
			strcpy(url, "C:/Users/lenovo/Desktop/");
			strcat(url, url_temp);
			//type
			strcpy(type, strchr(url_temp, '.') + 1); //jpg html png
			cout << "URL:" << url << endl;
			cout << "url_temp:" << url_temp << endl;
			cout << "type:" << type << endl;


			fp = fopen(url, "rb+");
			if (fp == NULL)
			{//404 not found
				strcpy(res, "HTTP/1.1 404 Not Found\r\nContent-Type: text/html;charset=ISO-8859-1\r\nContent-Length: 300\r\n\r\n<html><body><h1>404 Not Found</h1><p>Cr's server: URL is wrong.</p></body></html>\n\n");
				cout << res;
				send(socket, res, Config::BUFFERLENGTH, 0);
				//fclose(fp);
				return -1;
			}
			else
			{//����http��Ӧ���ı�
				lenth = fread(content, 1, Config::BUFFERLENGTH, fp);
				content[lenth] = '\0';
				//printf("%s", content);
			//	cout << content << endl; //��ӡ���Ķ�
				itoa(lenth, lenth_str, 10);

				//����html ��Ӧ����
				if (strcmp(type, "html") == 0)//HTML?
				{
					strcat(res, "HTTP/1.1 200 OK\r\nContent-Type: ");
					strcat(res, "text/");
					strcat(res, "html");//type
					strcat(res, ";charset=UTF-8859-1\r\n");
				}
				//���� jpg �� png
				if (strcmp(type, "jpg") == 0 || strcmp(type, "png") == 0)
				{
					strcat(res, "HTTP/1.1 200 OK\r\nCache-Control: no-cache\r\nContent-Type: ");
					strcat(res, "image/");
					if (strcmp(type, "jpg") == 0) {
						strcpy(type, "jpeg");
					}
					strcat(res, type);
					strcat(res, "\nAccept-Ranges: bytes\r\n");
				}
				strcat(res, "Content-Length: ");//��Ӧ���ĳ���
				strcat(res, lenth_str);
				strcat(res, "\r\n");
				strcat(res, "\r\n");
				cout << res << endl; //��ӡ�����ײ���
				//�ײ��н�������������Ӧ��������
				int i = 0;
				int now_lenth = (int)strlen(res);
				for (i = now_lenth; i < now_lenth + lenth; i++)
					res[i] = content[i - now_lenth]; 
			}
		}
		//cout << res << endl; //��ӡ��Ӧ����
		snd_result=send(socket, res, Config::BUFFERLENGTH, 0);  
		if (snd_result == SOCKET_ERROR) //����ʧ��
		{
			cerr << "Failed to send message to client! " << ::GetLastError() << "\n";
			::closesocket(socket);
			system("pause");
			return 1;
		}
		fclose(fp);
		if(socket==INVALID_SOCKET)
		   closesocket(socket);
		memset(req, '\0', Config::BUFFERLENGTH); //������ܻ�����
		memset(res, '\0', Config::BUFFERLENGTH);//�����Ӧ���Ķλ�����
	return 0;
}


int main()
{
	WORD sockVersion = MAKEWORD(2, 2);
	WSADATA wsaData;
	//��ʼ��winsock
	if (WSAStartup(sockVersion, &wsaData) != 0)
	{
		cout << "Winsock startup error!\n";
		return -1;
	}
	cout << "Winsock startup ok!\n";
	//�����׽���
	SOCKET srvsocket= socket(AF_INET, SOCK_STREAM, 0); //IPPROTO_TCP
	if (srvsocket == INVALID_SOCKET)
	{
		cout << "Server socket creare error !\n";
		WSACleanup();
		return -1;
	}
	cout << "Server socket creare ok !\n";
    //��IP�Ͷ˿�
	sockaddr_in srvAddr;  //��������IP��ַ
	char IPaddress[128];
	memset(IPaddress, '\0', 128);
	int port_number;
	cout << "Set IP for the Server:";
	cin >> IPaddress;
	srvAddr.sin_addr.s_addr = inet_addr(IPaddress);
	//srvAddr.sin_family = AF_INET;
	cout << "Set Port Number for the Server:";
	cin >> port_number;
	
	srvAddr.sin_family = AF_INET;
	//srvAddr.sin_port = htons(Config::PORT);
	if (port_number > 65535 || port_number < 0)
	{
		cout << "please input right pornumber(0~655365����";
		cin >>port_number;
	}
		srvAddr.sin_port = htons(port_number);
	//srvAddr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);//���Զ��ҵ����������ʵ�IP��ַ
	if (::bind(srvsocket, (LPSOCKADDR)&(srvAddr), sizeof(srvAddr)) == SOCKET_ERROR)
	{
		cout << "Server socket bind error!\n";
		closesocket(srvsocket);
		system("pause");
		WSACleanup();
		return -1;
	}
	cout << "Server socket bind ok !\n";
	//����listen�������õȴ�����״̬
	if (listen(srvsocket, Config::MAXCONNECTION) == SOCKET_ERROR)  
	{
		cout << "Server socket listen error!\n";
		closesocket(srvsocket);
		WSACleanup();
		return -1;
	}
	cout << "Server socket listen ok !\n";
	SOCKET sClient;
	sockaddr_in clt_Addr;
	int nAddrlen = sizeof(clt_Addr);
	char buf_ip[128];
	HANDLE h_thread;
	memset(buf_ip, '\0', Config::BUFIPSIZE);
	//HANDLE t_thread;
	thread k_thread(esc_key);
	k_thread.detach();
	//memset(rcvData, '\0', Config::BUFFERLENGTH);
	while (true)
	{
		//cout << "waiting for connecting ...\n";
		sClient = accept(srvsocket, (SOCKADDR *)&clt_Addr, &nAddrlen);
		if (sClient == INVALID_SOCKET)
		{
			cout << "socket accpet error !\n";
			closesocket(sClient);
			WSACleanup();
			return -1; //continue
		}
		cout << "A new client connected...\nIP address: ";
		cout << inet_ntoa(clt_Addr.sin_addr)<<"portnumber:"<< ntohs(clt_Addr.sin_port)<<endl;
		h_thread = ::CreateThread(nullptr, 0, CreateClientThread, (LPVOID)sClient, 0, nullptr);

		//��������*/
		if (h_thread == NULL)
		{
			cerr << "Failed to create a new thread!Error code: " << ::WSAGetLastError() << "\n";
			::WSACleanup();
			system("pause");
			return 1;
		}
		::CloseHandle(h_thread);
	}
	closesocket(srvsocket);
	closesocket(sClient);
	WSACleanup();
	return 0;
}